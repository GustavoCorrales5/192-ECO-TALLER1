package comunicacion;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Observable;

public class ControlCliente extends Observable implements Runnable{
	
	private Socket s;
	private ObjectOutputStream salida;
	private ObjectInputStream entrada;
	private int numeroCliente;

	public ControlCliente(Socket socketNuevoCliente,int numeroCli) {		
		try {
			numeroCliente=numeroCli;
			this.s = socketNuevoCliente;
			salida = new ObjectOutputStream(s.getOutputStream());
			entrada = new ObjectInputStream(s.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void run() {		
		while(true) {			
			try {
				recibir();
				Thread.sleep(30);
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (IOException e) {				
				e.printStackTrace();
				break;
			}
		}
	}

	private void recibir() throws IOException {
		if(s!=null && s.isConnected() && !s.isClosed()){		
		Object mensaje = null;
		try {
			mensaje =  entrada.readObject().toString();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	if(mensaje!=null) {
		setChanged();
		notifyObservers(""+numeroCliente+mensaje);
		clearChanged();
	}
		}		
	}

}
