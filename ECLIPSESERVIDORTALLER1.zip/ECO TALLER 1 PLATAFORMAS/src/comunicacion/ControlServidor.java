package comunicacion;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

public class ControlServidor extends Observable implements Runnable, Observer {

	private ServerSocket ss;
	private ArrayList<ControlCliente> clientes;
	private int numCliente = 1;

	public ControlServidor() {
		try {
			ss = new ServerSocket(5000);
			clientes = new ArrayList<>();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		while (true) {
			try {
				recibirClientes();
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private void recibirClientes() throws IOException {
		// 1. aceptamos la conexion
		Socket socketNuevoCliente = ss.accept();
		// 2. el socket resultante lo pasamos a la nueva instancia de control.

		ControlCliente nuevoControlCliente = new ControlCliente(socketNuevoCliente, numCliente);
		// 3. agregamos al control nuevo a los clientes
		clientes.add(nuevoControlCliente);
		numCliente = 2;
		// 4. iniciamos el cliente.
		Thread t = new Thread(nuevoControlCliente);
		t.start();
		// 5. agregar el observador
		nuevoControlCliente.addObserver(this);
		System.out.println("Ahora tengo " + clientes.size() + " Clientes");

	}

	@Override
	public void update(Observable o, Object arg) {
		System.out.println("CSERVIDOR: el mensaje es: " + (String) arg);

		setChanged();
		notifyObservers((String) arg);
		clearChanged();
	}

}
