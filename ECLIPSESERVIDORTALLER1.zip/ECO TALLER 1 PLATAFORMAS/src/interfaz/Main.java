package interfaz;

import ddf.minim.AudioPlayer;
import ddf.minim.AudioSample;
import ddf.minim.Minim;
import mundo.PantallaJuego;
import processing.core.PApplet;

public class Main extends PApplet {

	PantallaJuego juego;
	private Minim minim;
	private AudioPlayer musicaFondo;
	private AudioSample disparo;
	private AudioSample hit;

	public void settings() {
		size(1000, 800);
	}

	public void setup() {

		minim = new Minim(this);
		juego = new PantallaJuego(this);
		juego.start();
		musicaFondo = minim.loadFile("./1x/musicafondo.mp3");
		disparo = minim.loadSample("./1x/disparo.mp3");
		hit = minim.loadSample("./1x/golperecibido.mp3");
		musicaFondo.play();
		musicaFondo.loop();
	}

	public void keyPressed() {

		juego.moverPersonajes();
		/*
		 * if (key == 'L' || key == 'l' || key == 'f' || key == 'F') {
		 * disparo.trigger(); }
		 */
	}

	public void keyReleased() {
		juego.keyReleased();
	}

	public void draw() {
		background(0);
		juego.pintarEscenario();
		if (juego.getGolpe() == true) {
			System.out.println("entre");
			hit.trigger();
			juego.setGolpe(false);
		}

	}

	public static void main(String[] args) {
		PApplet.main("interfaz.Main");
	}

}
