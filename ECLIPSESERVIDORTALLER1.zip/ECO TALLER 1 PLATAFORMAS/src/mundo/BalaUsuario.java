package mundo;

import processing.core.PApplet;
import processing.core.PVector;

public class BalaUsuario {
	private PVector pos;
	private PVector vel;
	private PApplet app;
	private int direccion;

	public BalaUsuario(PApplet app, PVector pos, PVector vel, int direccion) {
		this.pos=pos;
		this.vel = vel;
		this.app = app;
		this.direccion=direccion;
	}



    

	public void pintar() {
		app.noStroke();
		app.fill(57,255,20);
		app.ellipse(pos.x, pos.y, 10, 10);
		pos.add(vel);
		
		if(direccion==0) {
			vel.x-=0.9;
		} else if(direccion==1) {
			vel.x+=0.9;
		}
	
		vel.mult((float) 0.9);

	}



	public PVector getPos() {
		return pos;
	}

	


	public void setPos(PVector pos) {
		this.pos = pos;
	}



	public PVector getVel() {
		return vel;
	}



	public void setVel(PVector vel) {
		this.vel = vel;
	}
	
	
}
