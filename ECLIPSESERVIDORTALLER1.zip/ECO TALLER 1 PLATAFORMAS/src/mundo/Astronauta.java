package mundo;

import java.util.ArrayList;

import org.jbox2d.dynamics.Body;

import javafx.css.PseudoClass;
import javafx.util.converter.PercentageStringConverter;
import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;

public class Astronauta {

	private PVector posPersonaje;
	private PVector velPersonaje;
	private int movimiento = 0;
	private int camino = 2;
	private boolean colision = false;
	private PApplet app;
	private int jugador;
	private int puntaje = 0;
	private PImage astronauta;
	private boolean llego;
	private boolean disparo = false;

	private String movimientoS="";
	private ArrayList<BalaUsuario> balas;
	// 0 mirando hacia la izquierda 1 mirando hacia la derecha
	private int posicion;
	// 0 puede saltar 1 ya salto 2 no puede saltar
	private int dobleSalto;

	public Astronauta(PApplet app, PVector posInicial, int jugador) {
		this.app = app;
		balas = new ArrayList<BalaUsuario>();

		this.posPersonaje = posInicial;
		this.jugador = jugador;
		crearPersonaje();

	}

	public void crearPersonaje() {
		velPersonaje = new PVector();

		if (jugador == 1) {
			posicion = 1;

		} else if (jugador == 2) {
			posicion = 0;

		}
	}

	public void pintarBalasUsuario() {
		for (int j = 0; j < balas.size(); j++) {
			balas.get(j).pintar();
			if (balas.get(j).getPos().x <= -1 || balas.get(j).getPos().x >= 1001) {
				balas.remove(j);
			}
		}
	}

	public void pintarPuntaje() {
		llego = false;
		if (!llego) {
			if (posPersonaje.y >= 850) {
				puntaje += 1;

				llego = true;
			}
		}

	}

	public int getPuntaje() {
		return puntaje;
	}

	public void pintarPersonaje() {
		if (jugador == 1) {
			app.fill(255, 134, 52);
			if (posicion == 1) {
				astronauta = app.loadImage("./1x/jugador1.png");
			} else if (posicion == 0) {
				astronauta = app.loadImage("./1x/jugador12.png");
			}
			app.image(astronauta, posPersonaje.x - 5, posPersonaje.y - 90);
		} else if (jugador == 2) {
			app.fill(93, 193, 185);
			if (posicion == 0) {
				astronauta = app.loadImage("./1x/jugador2.png");
			} else if (posicion == 1) {
				astronauta = app.loadImage("./1x/jugador22.png");
			}
			app.image(astronauta, posPersonaje.x - 25, posPersonaje.y - 90);

		}

		if (!colision) {
			velPersonaje.y += 0.8;
		} else if (colision) {
			switch (jugador) {
			case 1:
				if (movimientoS.equals("1saltar")) {
					velPersonaje.y -= 15;
					colision = false;

				} else {
					velPersonaje.y = 0;
				}
				break;

			case 2:
				if (movimientoS.equals("2saltar")) {
					velPersonaje.y -= 15;
					colision = false;
				} else {
					velPersonaje.y = 0;
				}
				break;
			}

		}

		pintarBalasUsuario();

		posPersonaje.add(velPersonaje);
		posPersonaje.x += movimiento;
		velPersonaje.mult((float) 0.9);

		pintarPuntaje();

		if (!colision) {
			dobleSalto = 0;
			
			if (dobleSalto == 0) {
				if (app.key == 'q') {
					posPersonaje.y -= 15;
					dobleSalto=1;
				}
				
				
			}
		} 
		if (colision || dobleSalto == 1) {
			dobleSalto = 2;
		}

		

	}

	public void moverPersonaje(String mov) {

		movimientoS=mov;
		switch (jugador) {
		case 1:
			if (mov.equals("1izquierda")) {

				if (!colision) {
					velPersonaje.y += 1;
				}

				posicion = 0;
				movimiento = -camino;

			} 
			if (mov.equals("1derecha")) {
				if (!colision) {
					velPersonaje.y += 1;
				}
				movimiento = camino;
				posicion = 1;

			}

			if (mov.equals("1disparo")) {
				if (balas.size() < 4) {
					disparo = true;

					if (posicion == 0) {
						balas.add(new BalaUsuario(app, new PVector(posPersonaje.x - 25, posPersonaje.y - 40),
								new PVector(0, 0), posicion));
					} else if (posicion == 1) {
						balas.add(new BalaUsuario(app, new PVector(posPersonaje.x + 60, posPersonaje.y - 40),
								new PVector(0, 0), posicion));
					}
				}
			}
			break;

		case 2:

			if (mov.equals("2izquierda")) {

				if (!colision) {
					velPersonaje.y += 1;
				}
				posicion = 0;

				movimiento = -camino;

			}
			if (mov.equals("2derecha")) {
				if (!colision) {
					velPersonaje.y += 1;
				}
				posicion = 1;

				movimiento = camino;

			}

			if (mov.equals("2saltar")) {

				if (colision) {
					velPersonaje.y -= 200;
					velPersonaje.mult(0.10f);
				} else {
					velPersonaje.y += 0.7;
				}
			}

			if (mov.equals("2disparo")) {

				if (balas.size() < 4) {
					disparo = true;

					if (posicion == 0) {
						balas.add(new BalaUsuario(app, new PVector(posPersonaje.x - 45, posPersonaje.y - 40),
								new PVector(0, 0), posicion));
					} else if (posicion == 1) {
						balas.add(new BalaUsuario(app, new PVector(posPersonaje.x + 45, posPersonaje.y - 40),
								new PVector(0, 0), posicion));
					}
				}
			}
			break;
		}

	}

	public void dejarDeMoverPersonaje(String mov) {

		switch (jugador) {
		case 1:
			if (mov.equals("1izquierda")) {
				movimiento = 0;
				posicion = 0;

			}
			if (mov.equals("1derecha")) {
				movimiento = 0;
				posicion = 1;

			}
			break;

		case 2:
			if (mov.equals("2izquierda")) {
				movimiento = 0;
				posicion = 0;
				break;

			}
			if (mov.equals("2derecha")) {
				movimiento = 0;
				posicion = 1;
				break;

			}
			break;

		}

	}

	public void retroceder(int posicionJugadorEnemigo) {

		if (posicionJugadorEnemigo == 1) {
			velPersonaje.x += 7;

		} else if (posicionJugadorEnemigo == 0) {
			velPersonaje.x -= 7;

		}

	}

	public void dejarDeRetroceder() {
		movimiento = 0;
	}

	public boolean isColision() {
		return colision;
	}

	public void setColision(boolean colision) {
		this.colision = colision;
	}

	public ArrayList<BalaUsuario> getBalas() {
		return balas;
	}

	public PVector getPosBala(int bala) {
		if (balas.get(bala) != null) {
			return balas.get(bala).getPos();
		}
		return null;
	}

	public PVector getPosPersonaje() {
		return posPersonaje;
	}

	public void setPosPersonaje(PVector posPersonaje) {
		this.posPersonaje = posPersonaje;
	}

	public PVector getVelPersonaje() {
		return velPersonaje;
	}

	public void setVelPersonaje(PVector velPersonaje) {
		this.velPersonaje = velPersonaje;
	}

	public boolean isLlego() {
		return llego;
	}

	public void setLlego(boolean llego) {
		this.llego = llego;
	}

	public int getPosicion() {
		return posicion;
	}

	public int getCantBalas() {
		// TODO Auto-generated method stub
		return balas.size();
	}

	public boolean getDisparo() {
		return disparo;
	}

	public void setDisparo(boolean d) {
		disparo = d;
	}

}
