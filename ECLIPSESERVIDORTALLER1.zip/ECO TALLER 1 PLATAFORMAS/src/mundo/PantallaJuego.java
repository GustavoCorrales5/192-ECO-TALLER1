package mundo;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;

import ddf.minim.AudioPlayer;
import ddf.minim.AudioSample;
import ddf.minim.Minim;
import processing.core.PApplet;
import processing.core.PFont;
import processing.core.PImage;
import processing.core.PVector;
import comunicacion.ControlServidor;

public class PantallaJuego extends Thread implements Observer{

	private PApplet app;
	private boolean colision = false;
	private PImage fondoReal;
	private PImage fondoColision;
	private PFont fuente;
	private ArrayList<Astronauta> astronautas;
	private ControlServidor servidor;


	private boolean golpe = false;
	
	private String orden1;
	private String orden2;

	public PantallaJuego(PApplet app) {

		this.app = app;
		astronautas = new ArrayList<Astronauta>();
		cargarFondos();
		anadirPersonaje();
		fuente = app.createFont("./1x/K2D-Bold.ttf", 15);
		
		servidor = new ControlServidor();
		servidor.addObserver(this);
		Thread t = new Thread(servidor);
		t.start();


	}

	public void anadirPersonaje() {
		astronautas.add(new Astronauta(app, new PVector(150, 100), 1));
		astronautas.add(new Astronauta(app, new PVector(800, 100), 2));
	}

	public void cargarFondos() {
		fondoReal = app.loadImage("./1x/fondoReal.png");
		fondoColision = app.loadImage("./1x/fondo.png");
	}



	public void pintarFondo() {
		app.image(fondoColision, 0, 0);
		app.image(fondoReal, 0, 0);
	}

	public void detectarColision() {

		for (int i = 0; i < astronautas.size(); i++) {
			int colorFondoColision = fondoColision.get((int) astronautas.get(i).getPosPersonaje().x,
					(int) astronautas.get(i).getPosPersonaje().y);

			if (colorFondoColision == -16777216) {
				astronautas.get(i).setColision(true);
			} else {
				astronautas.get(i).setColision(false);
			}

		}

		app.fill(255);
		app.textSize(15);

		app.textFont(fuente);
		app.text("PUNTAJE: " + astronautas.get(1).getPuntaje(), 170, 95);

		app.fill(255);

		app.text("PUNTAJE: " + astronautas.get(0).getPuntaje(), 740, 95);

	}

	public void detectarColisionBala() {

		boolean colision = false;
		if (astronautas.get(0).getBalas() != null) {
			if (astronautas.get(0).getBalas().size() >= 1) {
				for (int j = 0; j < astronautas.get(0).getBalas().size(); j++) {
					if (PApplet.dist(astronautas.get(1).getPosPersonaje().x,
							astronautas.get(1).getPosPersonaje().y - 50,
							astronautas.get(0).getBalas().get(j).getPos().x,
							astronautas.get(0).getBalas().get(j).getPos().y) <= 40) {
						golpe = true;
						if (colision != true) {
							colision = true;
							astronautas.get(0).getBalas().remove(j);
							astronautas.get(1).retroceder(astronautas.get(0).getPosicion());

							colision = false;
						}
					}
				}
			}
		}

		boolean colision2 = false;
		if (astronautas.get(1).getBalas() != null) {
			if (astronautas.get(1).getBalas().size() >= 1) {

				for (int j = 0; j < astronautas.get(1).getBalas().size(); j++) {

					if (PApplet.dist(astronautas.get(0).getPosPersonaje().x,
							astronautas.get(0).getPosPersonaje().y - 50,
							astronautas.get(1).getBalas().get(j).getPos().x,
							astronautas.get(1).getBalas().get(j).getPos().y) <= 40) {
						golpe = true;

						if (colision2 != true) {
							colision2 = true;
							astronautas.get(1).getBalas().remove(j);
							astronautas.get(0).retroceder(astronautas.get(1).getPosicion());

							colision2 = false;
						}
					}

				}
			}
		}

	}

	public void pintarPersonajes() {
		for (int i = 0; i < astronautas.size(); i++) {
			astronautas.get(i).pintarPersonaje();
		}
	}

	

	public void revivirJugador() {
		for (int i = 0; i < astronautas.size(); i++) {
			if (astronautas.get(i).getPosPersonaje().y >= 850) {
				astronautas.get(i).setPosPersonaje(new PVector(app.random(150, 800), -300));
			}
		}
	}

	public void pintarEscenario() {
		pintarFondo();
		pintarPersonajes();
		detectarColision();
		revivirJugador();
		detectarColision();
		detectarColisionBala();
		

	}

	public void run() {
		while (true) {
			try {
				sleep(60);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}

	public boolean getGolpe() {
		return golpe;
	}

	public void setGolpe(boolean g) {
		golpe = g;
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		System.out.println("ME LLEGO ESTA MONDA: " + (String)arg1);	
			orden1=(String)arg1;

				moverPersonajes();

			

		
	
	}

	public void keyReleased() {
		for (int i = 0; i < astronautas.size(); i++) {
			astronautas.get(i).dejarDeMoverPersonaje(orden1);
		}
	}
	
	public void moverPersonajes() {
		for (int i = 0; i < astronautas.size(); i++) {
			astronautas.get(i).moverPersonaje(orden1);
		}
	}
	

}
