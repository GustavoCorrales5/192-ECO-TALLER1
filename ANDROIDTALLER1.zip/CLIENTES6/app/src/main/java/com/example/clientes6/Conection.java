package com.example.clientes6;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Observable;

public class Conection  extends Observable implements Runnable {

    private Socket s;
    private ObjectOutputStream salida;
    private ObjectInputStream entrada;

    private String ip;
    private boolean conectado;
    public static Conection c;

    private Conection(){
        conectado = false;
    }

    @Override
    public void run() {
        while(true){
            if(!conectado){
                try {
                    s = new Socket("172.30.195.48", 5000);
                    // crear flujos
                    salida = new ObjectOutputStream(s.getOutputStream());
                    entrada = new ObjectInputStream(s.getInputStream());

                    conectado = true;
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                    break;
                }
            }else{
                try {
                    recibir();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }

                // hacer uso del socket para recibir
            }
            try {
                Thread.sleep(33);
            } catch (InterruptedException e) {
                e.printStackTrace();

            }
        }
    }

    public static Conection getInstance(){
        if(c==null){
            c=new Conection();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    new Thread(c).start();
                }
            }).start();
        }
        return c;
    }

    public void recibir() throws IOException, ClassNotFoundException {
        if(conectado){
            String m= entrada.readObject().toString();
            setChanged();
            notifyObservers((String) m);
            clearChanged();
        }
    }

    public void enviar(final Object mensaje){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(s!=null && s.isConnected()){
                    try {
                        salida.writeObject(mensaje);
                        salida.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    public String getIp(){
        return ip;
    }







}
