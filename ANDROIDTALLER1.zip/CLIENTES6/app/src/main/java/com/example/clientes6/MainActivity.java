package com.example.clientes6;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {


    private ImageButton left;
    private ImageButton right;

    private ImageButton jump;
    private ImageButton shoot;

    private EditText ip;
    private String ipS;
    private Button conectar;

    private Socket s;
    private OutputStream salida;
    boolean conectado=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        left=findViewById(R.id.btn_left);
        right=findViewById(R.id.btn_right);
        jump=findViewById(R.id.btn_jump);
        shoot=findViewById(R.id.btn_shoot);
        ip=findViewById(R.id.ed_ip);
        conectar=findViewById(R.id.btn_conectar);


        ipS=ip.getText().toString();

        conectar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Conection.getInstance();

            }
        });

        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("boton izquierda");
                Conection.getInstance().enviar("izquierda");

            }
        });


        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("boton derecha");
                Conection.getInstance().enviar("derecha");

            }
        });

        jump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Conection.getInstance().enviar("saltar");

            }
        });

        shoot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("boton disparo");
                Conection.getInstance().enviar("disparo");

            }
        });






    }





}
